/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,md,mdx,html,jsx,tsx}'],
  theme: { extend: {} },
  plugins: [],
};